package email;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.io.*;
import java.net.*;
import java.util.*;

/**
 * EmailClientGUI — Enhanced version
 *
 * New features added:
 *  1. Beautiful modern UI with custom logo and branding
 *  2. Email search / filter functionality
 *  3. Star / Favorite emails
 *  4. Unread email count badge on tab
 *  5. Reply to email
 *  6. Email statistics panel
 *  7. Character counter in compose
 *  8. Confirmation on send with preview
 *  9. Demo account quick-login buttons
 * 10. File size formatting
 */
public class EmailClientGUI extends JFrame {

    private Socket socket;
    private ObjectOutputStream out;
    private ObjectInputStream in;
    private String currentUser;

    private JPanel mainPanel;
    private CardLayout cardLayout;

    private JTextField usernameField;
    private JPasswordField passwordField;

    private JTable inboxTable, outboxTable;
    private DefaultTableModel inboxModel, outboxModel;
    private JLabel statusLabel, welcomeLabel;
    private JTabbedPane tabbedPane;
    private JTextField searchField;

    private JTextField toField, subjectField;
    private JTextArea bodyArea;
    private String currentAttachmentPath, currentAttachmentName;
    private JLabel attachmentLabel;
    private JLabel charCountLabel;

    private Set<String> starredEmails = new HashSet<>();

    // Colors
    private static final Color PRIMARY    = new Color(31, 87, 164);
    private static final Color SECONDARY  = new Color(16, 185, 129);
    private static final Color ACCENT     = new Color(245, 101, 52);
    private static final Color BG_LIGHT   = new Color(248, 250, 252);
    private static final Color CARD_BG    = Color.WHITE;
    private static final Color TEXT_DARK  = new Color(15, 23, 42);
    private static final Color TEXT_GRAY  = new Color(100, 116, 139);
    private static final Color BORDER_CLR = new Color(226, 232, 240);

    public EmailClientGUI() {
        setTitle("MailBox");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 780);
        setLocationRelativeTo(null);
        setIconImage(createLogoImage());
        setUIFont();

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        createLoginPanel();
        createMainPanel();

        add(mainPanel);
        cardLayout.show(mainPanel, "login");
        connectToServer();
    }

    private void setUIFont() {
        Font f = new Font("Segoe UI", Font.PLAIN, 13);
        UIManager.put("Button.font", f);
        UIManager.put("Label.font", f);
        UIManager.put("TextField.font", f);
        UIManager.put("TextArea.font", f);
        UIManager.put("Table.font", f);
        UIManager.put("TableHeader.font", new Font("Segoe UI", Font.BOLD, 13));
        UIManager.put("TabbedPane.font", new Font("Segoe UI", Font.BOLD, 13));
    }

    private Image createLogoImage() {
        java.awt.image.BufferedImage img =
                new java.awt.image.BufferedImage(64, 64, java.awt.image.BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(PRIMARY);
        g2.fillRoundRect(0, 0, 64, 64, 16, 16);
        g2.setColor(Color.WHITE);
        g2.setFont(new Font("Segoe UI", Font.BOLD, 36));
        g2.drawString("M", 14, 46);
        g2.dispose();
        return img;
    }

    private void connectToServer() {
        try {
            socket = new Socket("localhost", 5000);
            out = new ObjectOutputStream(socket.getOutputStream());
            out.flush();
            in = new ObjectInputStream(socket.getInputStream());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this,
                    "Could not connect to server!\nMake sure EmailServer is running.",
                    "Connection Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  LOGIN PANEL
    // ══════════════════════════════════════════════════════════════
    private void createLoginPanel() {
        JPanel loginPanel = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setPaint(new GradientPaint(0, 0, new Color(15, 32, 86),
                        getWidth(), getHeight(), new Color(26, 97, 180)));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setColor(new Color(255, 255, 255, 15));
                g2.fillOval(-80, -80, 400, 400);
                g2.fillOval(getWidth() - 200, getHeight() - 200, 400, 400);
            }
        };

        JPanel card = new JPanel(new GridBagLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(255, 255, 255, 245));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 24, 24);
            }
        };
        card.setOpaque(false);
        card.setPreferredSize(new Dimension(420, 560));
        card.setBorder(BorderFactory.createEmptyBorder(40, 40, 36, 40));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridwidth = 2;

        // Logo
        JPanel logoRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        logoRow.setOpaque(false);
        logoRow.add(makeLogoIcon(44));
        JLabel appName = new JLabel("MailBox");
        appName.setFont(new Font("Segoe UI", Font.BOLD, 26));
        appName.setForeground(TEXT_DARK);
        logoRow.add(appName);
        gbc.gridx = 0; gbc.gridy = 0; gbc.insets = new Insets(0, 0, 4, 0);
        card.add(logoRow, gbc);

        JLabel sub = new JLabel("Your professional email experience");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        sub.setForeground(TEXT_GRAY);
        sub.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridy = 1; gbc.insets = new Insets(0, 0, 26, 0);
        card.add(sub, gbc);

        gbc.gridy = 2; gbc.insets = new Insets(0, 0, 4, 0);
        card.add(boldLabel("Username"), gbc);
        gbc.gridy = 3; gbc.insets = new Insets(0, 0, 12, 0);
        usernameField = styledField("Enter your username");
        card.add(usernameField, gbc);

        gbc.gridy = 4; gbc.insets = new Insets(0, 0, 4, 0);
        card.add(boldLabel("Password"), gbc);
        gbc.gridy = 5; gbc.insets = new Insets(0, 0, 20, 0);
        passwordField = new JPasswordField();
        passwordField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        passwordField.setPreferredSize(new Dimension(0, 44));
        passwordField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_CLR, 1, true),
                BorderFactory.createEmptyBorder(8, 14, 8, 14)));
        passwordField.addActionListener(e -> performLogin());
        card.add(passwordField, gbc);

        gbc.gridy = 6; gbc.insets = new Insets(0, 0, 10, 0);
        JButton loginBtn = primaryBtn("Sign In →", PRIMARY);
        loginBtn.setPreferredSize(new Dimension(0, 46));
        loginBtn.addActionListener(e -> performLogin());
        card.add(loginBtn, gbc);

        gbc.gridy = 7; gbc.insets = new Insets(0, 0, 20, 0);
        JButton regBtn = outlineBtn("Create New Account");
        regBtn.addActionListener(e -> showRegisterDialog());
        card.add(regBtn, gbc);

        // Demo accounts
        gbc.gridy = 8; gbc.insets = new Insets(0, 0, 0, 0);
        JLabel demoLbl = new JLabel("Quick Login (Demo Accounts)");
        demoLbl.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        demoLbl.setForeground(TEXT_GRAY);
        demoLbl.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(demoLbl, gbc);

        gbc.gridy = 9; gbc.insets = new Insets(6, 0, 0, 0);
        JPanel demoRow = new JPanel(new GridLayout(1, 3, 8, 0));
        demoRow.setOpaque(false);
        String[][] demos = {{"alice","alice123"},{"bob","bob123"},{"charlie","charlie123"}};
        for (String[] d : demos) {
            JButton b = new JButton("<html><center><b>" + d[0] + "</b><br><font size=2>" + d[1] + "</font></center></html>");
            b.setBackground(new Color(241, 245, 249));
            b.setForeground(TEXT_DARK);
            b.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(BORDER_CLR, 1, true),
                    BorderFactory.createEmptyBorder(6, 4, 6, 4)));
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            b.addActionListener(e -> { usernameField.setText(d[0]); passwordField.setText(d[1]); performLogin(); });
            demoRow.add(b);
        }
        card.add(demoRow, gbc);

        JPanel wrap = new JPanel(new GridBagLayout());
        wrap.setOpaque(false);
        wrap.add(card);
        loginPanel.add(wrap, BorderLayout.CENTER);
        mainPanel.add(loginPanel, "login");
    }

    private JLabel makeLogoIcon(int size) {
        return new JLabel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(PRIMARY);
                g2.fillRoundRect(0, 0, size, size, size / 4, size / 4);
                g2.setColor(Color.WHITE);
                g2.setFont(new Font("Segoe UI", Font.BOLD, size / 2));
                g2.drawString("M", size / 4, size * 3 / 4);
            }
            @Override public Dimension getPreferredSize() { return new Dimension(size, size); }
        };
    }

    // ── Register dialog ───────────────────────────────────────────
    private void showRegisterDialog() {
        JDialog dlg = new JDialog(this, "Create New Account", true);
        dlg.setSize(400, 300);
        dlg.setLocationRelativeTo(this);
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(CARD_BG);
        p.setBorder(BorderFactory.createEmptyBorder(24, 28, 24, 28));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridwidth = 2; gbc.insets = new Insets(5, 0, 5, 0);

        JTextField ru = styledField("Username");
        JPasswordField rp = new JPasswordField(); stylePassField(rp);
        JPasswordField rp2 = new JPasswordField(); stylePassField(rp2);

        gbc.gridx=0;gbc.gridy=0;p.add(boldLabel("Username"),gbc);
        gbc.gridy=1;p.add(ru,gbc);
        gbc.gridy=2;p.add(boldLabel("Password"),gbc);
        gbc.gridy=3;p.add(rp,gbc);
        gbc.gridy=4;p.add(boldLabel("Confirm Password"),gbc);
        gbc.gridy=5;p.add(rp2,gbc);
        gbc.gridy=6;gbc.insets=new Insets(16,0,0,0);
        JButton btn = primaryBtn("Create Account", SECONDARY);
        btn.addActionListener(e -> {
            String u = ru.getText().trim();
            String p1 = new String(rp.getPassword()), p2 = new String(rp2.getPassword());
            if (u.isEmpty()||p1.isEmpty()){JOptionPane.showMessageDialog(dlg,"Fill all fields!");return;}
            if (!p1.equals(p2)){JOptionPane.showMessageDialog(dlg,"Passwords do not match!");return;}
            try {
                out.writeObject("REGISTER"); out.writeObject(u); out.writeObject(p1); out.flush();
                String resp=(String)in.readObject(), msg=(String)in.readObject();
                JOptionPane.showMessageDialog(dlg,msg,resp.equals("SUCCESS")?"Success":"Error",
                        resp.equals("SUCCESS")?JOptionPane.INFORMATION_MESSAGE:JOptionPane.ERROR_MESSAGE);
                if(resp.equals("SUCCESS")){usernameField.setText(u);dlg.dispose();}
            } catch(IOException|ClassNotFoundException ex){JOptionPane.showMessageDialog(dlg,"Server error: "+ex.getMessage());}
        });
        p.add(btn,gbc);
        dlg.add(p); dlg.setVisible(true);
    }

    private void performLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();
        if (username.isEmpty()||password.isEmpty()){JOptionPane.showMessageDialog(this,"Enter username and password!");return;}
        try {
            out.writeObject("LOGIN"); out.writeObject(username); out.writeObject(password); out.flush();
            String resp = (String)in.readObject();
            if ("SUCCESS".equals(resp)) {
                in.readObject();
                currentUser = username.toLowerCase();
                setTitle("MailBox  — "+currentUser);
                welcomeLabel.setText("Hello, "+currentUser+" 👋");
                updateStatus("Logged in as: "+currentUser);
                refreshInbox(); refreshOutbox();
                cardLayout.show(mainPanel,"main");
            } else {
                JOptionPane.showMessageDialog(this,(String)in.readObject(),"Login Failed",JOptionPane.ERROR_MESSAGE);
            }
        } catch(IOException|ClassNotFoundException e){JOptionPane.showMessageDialog(this,"Server error: "+e.getMessage());}
    }

    // ══════════════════════════════════════════════════════════════
    //  MAIN PANEL
    // ══════════════════════════════════════════════════════════════
    private void createMainPanel() {
        JPanel mp = new JPanel(new BorderLayout(0,0));
        mp.setBackground(BG_LIGHT);
        mp.add(buildHeader(), BorderLayout.NORTH);

        tabbedPane = new JTabbedPane();
        tabbedPane.setBackground(CARD_BG);
        tabbedPane.setFont(new Font("Segoe UI Emoji", Font.BOLD, 13));
        tabbedPane.addTab("  📥  Inbox  ", createInboxPanel());
        tabbedPane.addTab("  📤  Outbox  ", createOutboxPanel());
        tabbedPane.addTab("  ✏️  Compose  ", createComposePanel());
        tabbedPane.addTab("  📊  Stats  ", createStatsPanel());

        JPanel cw = new JPanel(new BorderLayout(10,10));
        cw.setBackground(BG_LIGHT);
        cw.setBorder(BorderFactory.createEmptyBorder(0,16,16,16));
        cw.add(tabbedPane, BorderLayout.CENTER);
        mp.add(cw, BorderLayout.CENTER);

        statusLabel = new JLabel("  Ready");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        statusLabel.setForeground(TEXT_GRAY);
        statusLabel.setBackground(new Color(241,245,249));
        statusLabel.setOpaque(true);
        statusLabel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1,0,0,0,BORDER_CLR),
                BorderFactory.createEmptyBorder(5,12,5,12)));
        mp.add(statusLabel, BorderLayout.SOUTH);
        mainPanel.add(mp,"main");
    }

    private JPanel buildHeader() {
        JPanel h = new JPanel(new BorderLayout(10,0)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setPaint(new GradientPaint(0,0,new Color(13,45,115),getWidth(),0,new Color(29,96,188)));
                g2.fillRect(0,0,getWidth(),getHeight());
                g2.setColor(new Color(255,255,255,10));
                g2.fillOval(getWidth()-140,-40,180,180);
                g2.fillOval(-30,-20,110,110);
            }
        };
        h.setPreferredSize(new Dimension(0,68));
        h.setBorder(BorderFactory.createEmptyBorder(10,20,10,20));

        // Left: logo + title + welcome stacked
        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT,12,0));
        left.setOpaque(false);
        left.add(makeLogoIcon(40));
        JPanel titleStack = new JPanel(new GridLayout(2,1,0,0));
        titleStack.setOpaque(false);
        JLabel title = new JLabel("MailBox ");
        title.setFont(new Font("Segoe UI", Font.BOLD, 17));
        title.setForeground(Color.WHITE);
        welcomeLabel = new JLabel("Welcome!");
        welcomeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        welcomeLabel.setForeground(new Color(170,205,255));
        titleStack.add(title);
        titleStack.add(welcomeLabel);
        left.add(titleStack);
        h.add(left, BorderLayout.WEST);

        // Center: Search bar - fully opaque background for visibility
        JPanel centerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 8));
        centerPanel.setOpaque(false);
        JPanel searchBox = new JPanel(new BorderLayout(4,0));
        searchBox.setBackground(new Color(255,255,255));
        searchBox.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(180,200,240),1,true),
            BorderFactory.createEmptyBorder(4,10,4,8)));
        searchBox.setPreferredSize(new Dimension(260,36));
        JLabel searchIconLbl = new JLabel("🔍");
        searchIconLbl.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 13));
        searchIconLbl.setForeground(new Color(100,120,180));
        searchField = new JTextField(16);
        searchField.setOpaque(false);
        searchField.setBorder(null);
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        searchField.setForeground(new Color(30,50,100));
        searchField.setCaretColor(new Color(30,50,100));
        searchField.setText("Search emails...");
        searchField.setForeground(new Color(150,165,200));
        searchField.addFocusListener(new FocusAdapter(){
            public void focusGained(FocusEvent e){
                if(searchField.getText().equals("Search emails...")){
                    searchField.setText("");
                    searchField.setForeground(new Color(30,50,100));
                }
            }
            public void focusLost(FocusEvent e){
                if(searchField.getText().isEmpty()){
                    searchField.setText("Search emails...");
                    searchField.setForeground(new Color(150,165,200));
                }
            }
        });
        searchField.addKeyListener(new KeyAdapter(){public void keyReleased(KeyEvent e){filterEmails();}});
        searchBox.add(searchIconLbl, BorderLayout.WEST);
        searchBox.add(searchField, BorderLayout.CENTER);
        centerPanel.add(searchBox);
        h.add(centerPanel, BorderLayout.CENTER);

        // Right: Sign out button
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT,8,0));
        right.setOpaque(false);
        JButton logout = new JButton("<html><center>⬅<br><font size=2>Sign Out</font></center></html>");
        logout.setFont(new Font("Segoe UI", Font.BOLD, 12));
        logout.setForeground(Color.WHITE);
        logout.setOpaque(false);
        logout.setContentAreaFilled(false);
        logout.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(255,255,255,90),1,true),
                BorderFactory.createEmptyBorder(7,16,7,16)));
        logout.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        logout.addActionListener(e -> logout());
        right.add(logout);
        h.add(right, BorderLayout.EAST);
        return h;
    }

    // ── Inbox panel ───────────────────────────────────────────────
    private JPanel createInboxPanel() {
        JPanel p = new JPanel(new BorderLayout(10,10));
        p.setBackground(CARD_BG);
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        String[] cols = {"⭐","From","Subject","Date/Time","Attachment"};
        inboxModel = new DefaultTableModel(cols,0){public boolean isCellEditable(int r,int c){return false;}};
        inboxTable = styledTable(inboxModel);
        inboxTable.getColumnModel().getColumn(0).setMaxWidth(38);
        inboxTable.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent e){
                if(e.getClickCount()==2) viewEmail(inboxTable,"inbox");
                if(e.getClickCount()==1 && inboxTable.getSelectedColumn()==0) toggleStar(inboxTable,"inbox");
            }
        });
        JScrollPane sc = new JScrollPane(inboxTable);
        sc.setBorder(BorderFactory.createLineBorder(BORDER_CLR,1));
        p.add(sc, BorderLayout.CENTER);
        p.add(styledBtnBar(
                new String[]{"🔄", "👁", "↩", "🗑", "🙈"},
                new String[]{"Refresh", "View", "Reply", "Delete", "Hide"},
                new Color[]{new Color(59,130,246), new Color(16,185,129), new Color(139,92,246), new Color(239,68,68), new Color(107,114,128)},
                new ActionListener[]{
                        e->refreshInbox(), e->viewEmail(inboxTable,"inbox"),
                        e->replyEmail(inboxTable), e->deleteEmail(inboxTable,"inbox"),
                        e->deleteForMe(inboxTable)}), BorderLayout.SOUTH);
        return p;
    }

    // ── Outbox panel ──────────────────────────────────────────────
    private JPanel createOutboxPanel() {
        JPanel p = new JPanel(new BorderLayout(10,10));
        p.setBackground(CARD_BG);
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        String[] cols = {"⭐","To","Subject","Date/Time","Attachment"};
        outboxModel = new DefaultTableModel(cols,0){public boolean isCellEditable(int r,int c){return false;}};
        outboxTable = styledTable(outboxModel);
        outboxTable.getColumnModel().getColumn(0).setMaxWidth(38);
        outboxTable.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent e){if(e.getClickCount()==2)viewEmail(outboxTable,"outbox");}
        });
        JScrollPane sc = new JScrollPane(outboxTable);
        sc.setBorder(BorderFactory.createLineBorder(BORDER_CLR,1));
        p.add(sc, BorderLayout.CENTER);
        p.add(styledBtnBar(
                new String[]{"🔄", "👁", "✏", "🗑"},
                new String[]{"Refresh", "View", "Edit", "Delete"},
                new Color[]{new Color(59,130,246), new Color(16,185,129), new Color(245,158,11), new Color(239,68,68)},
                new ActionListener[]{
                        e->refreshOutbox(), e->viewEmail(outboxTable,"outbox"),
                        e->editEmail(), e->deleteEmail(outboxTable,"outbox")}), BorderLayout.SOUTH);
        return p;
    }

    // ── Compose panel ─────────────────────────────────────────────
    private JPanel createComposePanel() {
        JPanel outer = new JPanel(new BorderLayout(10,10));
        outer.setBackground(CARD_BG);
        outer.setBorder(BorderFactory.createEmptyBorder(16,16,16,16));

        JLabel title = new JLabel("✏  Compose New Email");
        title.setFont(new Font("Segoe UI",Font.BOLD,16));
        title.setForeground(TEXT_DARK);
        title.setBorder(BorderFactory.createEmptyBorder(0,0,10,0));
        outer.add(title, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(CARD_BG);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,0,5,8); gbc.fill=GridBagConstraints.HORIZONTAL;

        gbc.gridx=0;gbc.gridy=0;gbc.weightx=0;form.add(boldLabel("To:"),gbc);
        gbc.gridx=1;gbc.weightx=1;
        toField=styledField("recipient username");form.add(toField,gbc);

        gbc.gridx=0;gbc.gridy=1;gbc.weightx=0;form.add(boldLabel("Subject:"),gbc);
        gbc.gridx=1;gbc.weightx=1;
        subjectField=styledField("Email subject");form.add(subjectField,gbc);

        gbc.gridx=0;gbc.gridy=2;gbc.weightx=0;form.add(boldLabel("Attach:"),gbc);
        gbc.gridx=1;
        JPanel attRow=new JPanel(new FlowLayout(FlowLayout.LEFT,8,0));
        attRow.setBackground(CARD_BG);
        JButton attBtn=iconLabelBtn("📎", "Choose File", new Color(59,130,246));
        attBtn.addActionListener(e->chooseFile());
        attachmentLabel=new JLabel("No file selected");
        attachmentLabel.setForeground(TEXT_GRAY);
        attachmentLabel.setFont(new Font("Segoe UI",Font.ITALIC,12));
        attRow.add(attBtn);attRow.add(attachmentLabel);
        form.add(attRow,gbc);

        JPanel bodyPanel=new JPanel(new BorderLayout(0,4));
        bodyPanel.setBackground(CARD_BG);
        bodyPanel.add(boldLabel("Message:"),BorderLayout.NORTH);
        bodyArea=new JTextArea(12,50);
        bodyArea.setFont(new Font("Segoe UI",Font.PLAIN,13));
        bodyArea.setLineWrap(true); bodyArea.setWrapStyleWord(true);
        bodyArea.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_CLR,1,true),
                BorderFactory.createEmptyBorder(10,12,10,12)));
        charCountLabel=new JLabel("0 characters");
        charCountLabel.setFont(new Font("Segoe UI",Font.PLAIN,11));
        charCountLabel.setForeground(TEXT_GRAY);
        bodyArea.getDocument().addDocumentListener(new javax.swing.event.DocumentListener(){
            public void insertUpdate(javax.swing.event.DocumentEvent e){updateCharCount();}
            public void removeUpdate(javax.swing.event.DocumentEvent e){updateCharCount();}
            public void changedUpdate(javax.swing.event.DocumentEvent e){updateCharCount();}
        });
        bodyPanel.add(new JScrollPane(bodyArea),BorderLayout.CENTER);
        bodyPanel.add(charCountLabel,BorderLayout.SOUTH);

        JPanel center=new JPanel(new BorderLayout(10,10));
        center.setBackground(CARD_BG);
        center.add(form,BorderLayout.NORTH);
        center.add(bodyPanel,BorderLayout.CENTER);

        JPanel sendBar=new JPanel(new FlowLayout(FlowLayout.RIGHT,10,0));
        sendBar.setBackground(CARD_BG);
        sendBar.setBorder(BorderFactory.createEmptyBorder(8,0,0,0));
        JButton clearBtn=iconLabelBtn("🗑", "Clear", new Color(107,114,128));
        clearBtn.addActionListener(e->{
            toField.setText("");subjectField.setText("");bodyArea.setText("");
            currentAttachmentPath=null;currentAttachmentName=null;
            attachmentLabel.setText("No file selected");attachmentLabel.setForeground(TEXT_GRAY);
        });
        JButton sendBtn=iconLabelBtn("📨", "Send Email", PRIMARY);
        sendBtn.setPreferredSize(new Dimension(140,56));
        sendBtn.addActionListener(e->sendEmail());
        sendBar.add(clearBtn);sendBar.add(sendBtn);
        center.add(sendBar,BorderLayout.SOUTH);

        outer.add(center,BorderLayout.CENTER);
        return outer;
    }

    // ── Stats panel ───────────────────────────────────────────────
    private JPanel createStatsPanel() {
        JPanel p=new JPanel(new BorderLayout(20,20));
        p.setBackground(BG_LIGHT);
        p.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));

        JLabel title=new JLabel("📊  Email Statistics");
        title.setFont(new Font("Segoe UI",Font.BOLD,18));
        title.setForeground(TEXT_DARK);
        p.add(title,BorderLayout.NORTH);

        JPanel grid=new JPanel(new GridLayout(2,3,16,16));
        grid.setBackground(BG_LIGHT);
        Object[][] defs={
                {"📥","Total Received","0",PRIMARY},
                {"📤","Total Sent","0",SECONDARY},
                {"⭐","Starred","0",new Color(251,191,36)},
                {"📎","With Attachments","0",new Color(139,92,246)},
                {"💬","Avg Msg Length","0 chars",new Color(6,182,212)},
                {"👤","Active User","—",ACCENT}
        };
        for(Object[] d:defs) grid.add(statCard((String)d[0],(String)d[1],(String)d[2],(Color)d[3]));
        p.add(grid,BorderLayout.CENTER);

        JButton rb=iconLabelBtn("🔄", "Refresh Statistics", PRIMARY);
        rb.setPreferredSize(new Dimension(180,56));
        rb.addActionListener(e->updateStats(grid));
        JPanel bot=new JPanel(new FlowLayout(FlowLayout.CENTER));
        bot.setBackground(BG_LIGHT);bot.add(rb);
        p.add(bot,BorderLayout.SOUTH);
        return p;
    }

    private JPanel statCard(String icon,String label,String value,Color accent) {
        JPanel card=new JPanel(new BorderLayout(10,0)){
            @Override protected void paintComponent(Graphics g){
                Graphics2D g2=(Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_BG);g2.fillRoundRect(0,0,getWidth(),getHeight(),16,16);
                g2.setColor(accent);g2.fillRoundRect(0,0,6,getHeight(),6,6);
                g2.setColor(new Color(accent.getRed(),accent.getGreen(),accent.getBlue(),20));
                g2.fillRoundRect(0,0,getWidth(),getHeight(),16,16);
            }
        };
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(16,20,16,16));
        JLabel ic=new JLabel(icon);
        ic.setFont(new Font("Segoe UI Emoji",Font.PLAIN,28));
        card.add(ic,BorderLayout.WEST);
        JPanel txt=new JPanel(new GridLayout(2,1));
        txt.setOpaque(false);
        JLabel vl=new JLabel(value);
        vl.setName("value");
        vl.setFont(new Font("Segoe UI",Font.BOLD,22));
        vl.setForeground(accent);
        JLabel nl=new JLabel(label);
        nl.setFont(new Font("Segoe UI",Font.PLAIN,12));
        nl.setForeground(TEXT_GRAY);
        txt.add(vl);txt.add(nl);
        card.add(txt,BorderLayout.CENTER);
        return card;
    }

    @SuppressWarnings("unchecked")
    private void updateStats(JPanel grid) {
        try {
            out.writeObject("GET_INBOX");out.flush();
            java.util.List<EmailData> inbox=(java.util.List<EmailData>)in.readObject();
            out.writeObject("GET_OUTBOX");out.flush();
            java.util.List<EmailData> outbox=(java.util.List<EmailData>)in.readObject();
            int inC=inbox.size(),outC=outbox.size(),starred=starredEmails.size();
            long att=inbox.stream().filter(e->e.attachmentName!=null).count()
                    +outbox.stream().filter(e->e.attachmentName!=null).count();
            int avg=inC>0?(int)(inbox.stream().mapToInt(e->e.body!=null?e.body.length():0).sum()/inC):0;
            String[] vals={String.valueOf(inC),String.valueOf(outC),String.valueOf(starred),
                    String.valueOf(att),avg+" chars",currentUser!=null?currentUser:"—"};
            Component[] cards=grid.getComponents();
            for(int i=0;i<cards.length&&i<vals.length;i++){
                if(cards[i] instanceof JPanel){
                    for(Component c:((JPanel)cards[i]).getComponents()){
                        if(c instanceof JPanel){
                            for(Component inner:((JPanel)c).getComponents()){
                                if(inner instanceof JLabel&&"value".equals(((JLabel)inner).getName()))
                                    ((JLabel)inner).setText(vals[i]);
                            }
                        }
                    }
                }
            }
            grid.repaint();
            updateStatus("Stats refreshed!");
        } catch(IOException|ClassNotFoundException e){updateStatus("Stats error: "+e.getMessage());}
    }

    // ══════════════════════════════════════════════════════════════
    //  EMAIL OPERATIONS
    // ══════════════════════════════════════════════════════════════
    private void updateCharCount(){
        int len=bodyArea.getText().length();
        charCountLabel.setText(len+" characters");
        charCountLabel.setForeground(len>5000?ACCENT:TEXT_GRAY);
    }

    private void filterEmails(){
        String q=searchField.getText().toLowerCase().trim();
        if(q.isEmpty()||q.equals("search emails...")){refreshInbox();refreshOutbox();return;}
        filterTable(inboxModel,q,true);
        filterTable(outboxModel,q,false);
    }

    @SuppressWarnings("unchecked")
    private void filterTable(DefaultTableModel model,String q,boolean isInbox){
        try{
            out.writeObject(isInbox?"GET_INBOX":"GET_OUTBOX");out.flush();
            java.util.List<EmailData> emails=(java.util.List<EmailData>)in.readObject();
            model.setRowCount(0);
            for(EmailData e:emails){
                if(((isInbox?e.from:e.to)+" "+e.subject+" "+e.body).toLowerCase().contains(q)){
                    model.addRow(new Object[]{
                            starredEmails.contains(e.messageId)?"⭐":"",
                            isInbox?e.from:e.to,e.subject,e.timestamp,
                            e.attachmentName!=null?"📎 "+e.attachmentName:""});
                }
            }
        }catch(IOException|ClassNotFoundException ex){updateStatus("Filter error: "+ex.getMessage());}
    }

    @SuppressWarnings("unchecked")
    private void toggleStar(JTable table,String folder){
        int row=table.getSelectedRow();if(row==-1)return;
        try{
            out.writeObject("inbox".equals(folder)?"GET_INBOX":"GET_OUTBOX");out.flush();
            java.util.List<EmailData> emails=(java.util.List<EmailData>)in.readObject();
            if(row<emails.size()){
                String id=emails.get(row).messageId;
                if(starredEmails.contains(id))starredEmails.remove(id);else starredEmails.add(id);
                if("inbox".equals(folder))refreshInbox();else refreshOutbox();
            }
        }catch(IOException|ClassNotFoundException e){updateStatus("Star error: "+e.getMessage());}
    }

    private void chooseFile(){
        JFileChooser fc=new JFileChooser();
        if(fc.showOpenDialog(this)==JFileChooser.APPROVE_OPTION){
            File f=fc.getSelectedFile();
            currentAttachmentPath=f.getAbsolutePath();
            currentAttachmentName=f.getName();
            attachmentLabel.setText("📎 "+f.getName()+" ("+fmtSize(f.length())+")");
            attachmentLabel.setForeground(SECONDARY);
        }
    }

    private String fmtSize(long b){
        if(b<1024)return b+" B";
        if(b<1048576)return String.format("%.1f KB",b/1024.0);
        return String.format("%.1f MB",b/1048576.0);
    }

    private void sendEmail(){
        String to=toField.getText().trim(),subject=subjectField.getText().trim(),body=bodyArea.getText().trim();
        if(to.isEmpty()||subject.isEmpty()||body.isEmpty()){JOptionPane.showMessageDialog(this,"Fill To, Subject, and Message!");return;}
        if(JOptionPane.showConfirmDialog(this,"Send to: "+to+"\nSubject: "+subject+"\n\nSend now?",
                "Confirm Send",JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION)return;
        try{
            String sp=null,an=null;
            if(currentAttachmentPath!=null){
                sp=uploadAttachment(currentAttachmentPath);an=currentAttachmentName;
                if(sp==null){JOptionPane.showMessageDialog(this,"Attachment upload failed!");return;}
            }
            out.writeObject("SEND_EMAIL");out.writeObject(to);out.writeObject(subject);
            out.writeObject(body);out.writeObject(sp);out.writeObject(an);out.flush();
            String resp=(String)in.readObject(),msg=(String)in.readObject();
            if("SUCCESS".equals(resp)){
                JOptionPane.showMessageDialog(this,"✅ "+msg);
                toField.setText("");subjectField.setText("");bodyArea.setText("");
                currentAttachmentPath=null;currentAttachmentName=null;
                attachmentLabel.setText("No file selected");attachmentLabel.setForeground(TEXT_GRAY);
                refreshOutbox();refreshInbox();tabbedPane.setSelectedIndex(0);
                updateStatus("Email sent to "+to+"!");
            }else{JOptionPane.showMessageDialog(this,msg,"Error",JOptionPane.ERROR_MESSAGE);}
        }catch(IOException|ClassNotFoundException e){JOptionPane.showMessageDialog(this,"Error: "+e.getMessage());}
    }

    @SuppressWarnings("unchecked")
    private void replyEmail(JTable table){
        int row=table.getSelectedRow();
        if(row==-1){JOptionPane.showMessageDialog(this,"Select an email to reply!");return;}
        try{
            out.writeObject("GET_INBOX");out.flush();
            java.util.List<EmailData> emails=(java.util.List<EmailData>)in.readObject();
            if(row>=emails.size())return;
            EmailData e=emails.get(row);
            toField.setText(e.from);
            subjectField.setText("Re: "+e.subject);
            bodyArea.setText("\n\n─────────────────────\nFrom: "+e.from+"\nDate: "+e.timestamp+"\n\n"+e.body);
            tabbedPane.setSelectedIndex(2);toField.requestFocus();
        }catch(IOException|ClassNotFoundException ex){JOptionPane.showMessageDialog(this,"Error: "+ex.getMessage());}
    }

    private String uploadAttachment(String filePath){
        File file=new File(filePath);if(!file.exists()){updateStatus("File not found.");return null;}
        updateStatus("Uploading "+file.getName()+"…");
        try{
            out.writeObject("UPLOAD_ATTACHMENT");out.writeObject(file.getName());out.writeObject(file.length());out.flush();
            try(FileInputStream fis=new FileInputStream(file)){
                byte[] buf=new byte[8192];int n;
                while((n=fis.read(buf))!=-1){out.write(buf,0,n);}out.flush();
            }
            String resp=(String)in.readObject();
            if("SUCCESS".equals(resp)){String sp=(String)in.readObject(),un=(String)in.readObject();updateStatus("Uploaded: "+un);return sp;}
            else{String err=(String)in.readObject();updateStatus("Upload failed: "+err);return null;}
        }catch(IOException|ClassNotFoundException e){updateStatus("Upload error: "+e.getMessage());return null;}
    }

    @SuppressWarnings("unchecked")
    private void refreshInbox(){
        try{
            out.writeObject("GET_INBOX");out.flush();
            java.util.List<EmailData> emails=(java.util.List<EmailData>)in.readObject();
            inboxModel.setRowCount(0);
            for(EmailData e:emails){
                inboxModel.addRow(new Object[]{
                        starredEmails.contains(e.messageId)?"⭐":"",
                        e.from,e.subject,e.timestamp,
                        e.attachmentName!=null?"📎 "+e.attachmentName:""});
            }
            tabbedPane.setTitleAt(0,"  📥  Inbox ("+emails.size()+")  ");
            updateStatus("Inbox: "+emails.size()+" message(s)");
        }catch(IOException|ClassNotFoundException e){updateStatus("Inbox error: "+e.getMessage());}
    }

    @SuppressWarnings("unchecked")
    private void refreshOutbox(){
        try{
            out.writeObject("GET_OUTBOX");out.flush();
            java.util.List<EmailData> emails=(java.util.List<EmailData>)in.readObject();
            outboxModel.setRowCount(0);
            for(EmailData e:emails){
                outboxModel.addRow(new Object[]{
                        starredEmails.contains(e.messageId)?"⭐":"",
                        e.to,e.subject,e.timestamp,
                        e.attachmentName!=null?"📎 "+e.attachmentName:""});
            }
            tabbedPane.setTitleAt(1,"  📤  Outbox ("+emails.size()+")  ");
            updateStatus("Outbox: "+emails.size()+" message(s)");
        }catch(IOException|ClassNotFoundException e){updateStatus("Outbox error: "+e.getMessage());}
    }

    @SuppressWarnings("unchecked")
    private void viewEmail(JTable table,String folder){
        int row=table.getSelectedRow();if(row==-1)return;
        try{
            out.writeObject("inbox".equals(folder)?"GET_INBOX":"GET_OUTBOX");out.flush();
            java.util.List<EmailData> emails=(java.util.List<EmailData>)in.readObject();
            if(row>=emails.size())return;
            EmailData email=emails.get(row);

            JDialog dlg=new JDialog(this,"📧 "+email.subject,true);
            dlg.setSize(680,520);dlg.setLocationRelativeTo(this);
            JPanel pnl=new JPanel(new BorderLayout(12,12));
            pnl.setBackground(CARD_BG);
            pnl.setBorder(BorderFactory.createEmptyBorder(20,24,20,24));

            JPanel hdr=new JPanel(new GridLayout(0,1,3,3));
            hdr.setBackground(new Color(248,250,252));
            hdr.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(BORDER_CLR,1,true),
                    BorderFactory.createEmptyBorder(12,14,12,14)));
            addInfo(hdr,"From",email.from);addInfo(hdr,"To",email.to);
            addInfo(hdr,"Subject",email.subject);addInfo(hdr,"Time",email.timestamp);
            if(email.attachmentName!=null)addInfo(hdr,"📎 Attachment",email.attachmentName);
            pnl.add(hdr,BorderLayout.NORTH);

            JTextArea ta=new JTextArea(email.body);
            ta.setEditable(false);ta.setFont(new Font("Segoe UI",Font.PLAIN,13));
            ta.setLineWrap(true);ta.setWrapStyleWord(true);ta.setBackground(CARD_BG);
            ta.setBorder(BorderFactory.createEmptyBorder(10,4,10,4));
            JScrollPane sc=new JScrollPane(ta);
            sc.setBorder(BorderFactory.createLineBorder(BORDER_CLR,1));
            pnl.add(sc,BorderLayout.CENTER);

            JPanel br=new JPanel(new FlowLayout(FlowLayout.RIGHT,8,0));
            br.setBackground(CARD_BG);
            if(email.attachmentPath!=null){
                JButton dl=primaryBtn("📥 Download",SECONDARY);
                dl.addActionListener(e->{dlg.dispose();downloadAttachment(email.attachmentPath);});
                br.add(dl);
            }
            if("inbox".equals(folder)){
                JButton rep=primaryBtn("↩ Reply",PRIMARY);
                rep.addActionListener(e->{
                    toField.setText(email.from);subjectField.setText("Re: "+email.subject);
                    bodyArea.setText("\n\n─────────────────────\nFrom: "+email.from+"\nDate: "+email.timestamp+"\n\n"+email.body);
                    dlg.dispose();tabbedPane.setSelectedIndex(2);
                });
                br.add(rep);
            }
            JButton cl=outlineBtn("Close");cl.addActionListener(e->dlg.dispose());br.add(cl);
            pnl.add(br,BorderLayout.SOUTH);
            dlg.add(pnl);dlg.setVisible(true);
        }catch(IOException|ClassNotFoundException e){JOptionPane.showMessageDialog(this,"Error: "+e.getMessage());}
    }

    private void addInfo(JPanel p,String key,String val){
        JLabel l=new JLabel("<html><b>"+key+":</b>  "+val+"</html>");
        l.setFont(new Font("Segoe UI",Font.PLAIN,13));l.setForeground(TEXT_DARK);p.add(l);
    }

    private void downloadAttachment(String filePath){
        try{
            out.writeObject("DOWNLOAD_ATTACHMENT");out.writeObject(filePath);out.flush();
            String resp=(String)in.readObject();
            if(!"SUCCESS".equals(resp)){JOptionPane.showMessageDialog(this,(String)in.readObject(),"Error",JOptionPane.ERROR_MESSAGE);return;}
            long sz=(Long)in.readObject();String fn=(String)in.readObject();
            JFileChooser fc=new JFileChooser();fc.setSelectedFile(new File(fn));
            if(fc.showSaveDialog(this)!=JFileChooser.APPROVE_OPTION)return;
            try(FileOutputStream fos=new FileOutputStream(fc.getSelectedFile())){
                byte[] buf=new byte[8192];long rem=sz;
                while(rem>0){int n=in.read(buf,0,(int)Math.min(buf.length,rem));if(n==-1)break;fos.write(buf,0,n);rem-=n;}
                fos.flush();
            }
            JOptionPane.showMessageDialog(this,"✅ Saved: "+fc.getSelectedFile().getName());
            updateStatus("Downloaded: "+fn);
        }catch(IOException|ClassNotFoundException e){JOptionPane.showMessageDialog(this,"Download error: "+e.getMessage());}
    }

    @SuppressWarnings("unchecked")
    private void deleteEmail(JTable table,String folder){
        int row=table.getSelectedRow();
        if(row==-1){JOptionPane.showMessageDialog(this,"Select an email first!");return;}
        if(JOptionPane.showConfirmDialog(this,"Delete this email permanently?","Confirm",
                JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE)!=JOptionPane.YES_OPTION)return;
        try{
            out.writeObject("inbox".equals(folder)?"GET_INBOX":"GET_OUTBOX");out.flush();
            java.util.List<EmailData> emails=(java.util.List<EmailData>)in.readObject();
            if(row>=emails.size())return;
            out.writeObject("DELETE_EMAIL");out.writeObject(emails.get(row).messageId);out.writeObject(folder);out.flush();
            String resp=(String)in.readObject(),msg=(String)in.readObject();
            JOptionPane.showMessageDialog(this,msg);
            if("inbox".equals(folder))refreshInbox();else refreshOutbox();
        }catch(IOException|ClassNotFoundException e){JOptionPane.showMessageDialog(this,"Error: "+e.getMessage());}
    }

    @SuppressWarnings("unchecked")
    private void deleteForMe(JTable table){
        int row=table.getSelectedRow();
        if(row==-1){JOptionPane.showMessageDialog(this,"Select an email first!");return;}
        if(JOptionPane.showConfirmDialog(this,"Hide from your inbox only?","Confirm",
                JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION)return;
        try{
            out.writeObject("GET_INBOX");out.flush();
            java.util.List<EmailData> emails=(java.util.List<EmailData>)in.readObject();
            if(row>=emails.size())return;
            out.writeObject("DELETE_FOR_ME");out.writeObject(emails.get(row).messageId);out.flush();
            String resp=(String)in.readObject(),msg=(String)in.readObject();
            JOptionPane.showMessageDialog(this,msg);
            if("SUCCESS".equals(resp))refreshInbox();
        }catch(IOException|ClassNotFoundException e){JOptionPane.showMessageDialog(this,"Error: "+e.getMessage());}
    }

    @SuppressWarnings("unchecked")
    private void editEmail(){
        int row=outboxTable.getSelectedRow();
        if(row==-1){JOptionPane.showMessageDialog(this,"Select an email to edit!");return;}
        try{
            out.writeObject("GET_OUTBOX");out.flush();
            java.util.List<EmailData> emails=(java.util.List<EmailData>)in.readObject();
            if(row>=emails.size())return;
            EmailData email=emails.get(row);
            JDialog dlg=new JDialog(this,"✏ Edit Email",true);
            dlg.setSize(540,440);dlg.setLocationRelativeTo(this);
            JPanel pnl=new JPanel(new BorderLayout(10,10));
            pnl.setBackground(CARD_BG);pnl.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
            JPanel frm=new JPanel(new GridLayout(2,2,8,8));frm.setBackground(CARD_BG);
            JTextField subj=styledField("");subj.setText(email.subject);
            frm.add(boldLabel("Subject:"));frm.add(subj);
            frm.add(boldLabel("Body (below):"));frm.add(new JLabel());
            pnl.add(frm,BorderLayout.NORTH);
            JTextArea body=new JTextArea(email.body,10,40);
            body.setFont(new Font("Segoe UI",Font.PLAIN,13));body.setLineWrap(true);body.setWrapStyleWord(true);
            pnl.add(new JScrollPane(body),BorderLayout.CENTER);
            JButton save=primaryBtn("💾 Save Changes",SECONDARY);
            save.addActionListener(e->{
                try{
                    out.writeObject("EDIT_EMAIL");out.writeObject(email.messageId);
                    out.writeObject(subj.getText());out.writeObject(body.getText());out.flush();
                    String resp=(String)in.readObject(),msg=(String)in.readObject();
                    JOptionPane.showMessageDialog(dlg,msg);
                    if("SUCCESS".equals(resp)){refreshOutbox();dlg.dispose();}
                }catch(IOException|ClassNotFoundException ex){JOptionPane.showMessageDialog(dlg,"Error: "+ex.getMessage());}
            });
            pnl.add(save,BorderLayout.SOUTH);
            dlg.add(pnl);dlg.setVisible(true);
        }catch(IOException|ClassNotFoundException e){JOptionPane.showMessageDialog(this,"Error: "+e.getMessage());}
    }

    private void logout(){
        try{out.writeObject("LOGOUT");out.flush();in.readObject();}catch(IOException|ClassNotFoundException ignored){}
        currentUser=null;usernameField.setText("");passwordField.setText("");
        setTitle("MailBox Pro");cardLayout.show(mainPanel,"login");updateStatus("Logged out.");
        try{socket.close();}catch(IOException ignored){}
        connectToServer();
    }

    // ══════════════════════════════════════════════════════════════
    //  UI HELPERS
    // ══════════════════════════════════════════════════════════════
    private JTable styledTable(DefaultTableModel model){
        JTable t=new JTable(model);
        t.setRowHeight(34);t.setFont(new Font("Segoe UI",Font.PLAIN,13));
        t.setForeground(TEXT_DARK);t.setBackground(CARD_BG);
        t.setSelectionBackground(new Color(219,234,254));t.setSelectionForeground(TEXT_DARK);
        t.setGridColor(new Color(241,245,249));t.setShowVerticalLines(false);
        t.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,12));
        t.getTableHeader().setBackground(new Color(248,250,252));
        t.getTableHeader().setForeground(TEXT_GRAY);
        t.getTableHeader().setBorder(BorderFactory.createMatteBorder(0,0,2,0,BORDER_CLR));
        t.setFillsViewportHeight(true);
        return t;
    }

    private JPanel btnBar(String[] labels,ActionListener[] actions){
        JPanel bar=new JPanel(new FlowLayout(FlowLayout.LEFT,8,8));
        bar.setBackground(CARD_BG);
        bar.setBorder(BorderFactory.createMatteBorder(1,0,0,0,BORDER_CLR));
        for(int i=0;i<labels.length;i++){
            JButton b=outlineBtn(labels[i]);b.addActionListener(actions[i]);bar.add(b);
        }
        return bar;
    }

    private JPanel styledBtnBar(String[] icons, String[] labels, Color[] colors, ActionListener[] actions){
        JPanel bar=new JPanel(new FlowLayout(FlowLayout.LEFT,10,10));
        bar.setBackground(new Color(248,250,252));
        bar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1,0,0,0,BORDER_CLR),
            BorderFactory.createEmptyBorder(2,2,2,2)));
        for(int i=0;i<labels.length;i++){
            final Color col = colors[i];
            final String ico = icons[i];
            final String lbl = labels[i];
            JButton b = new JButton() {
                {
                    setText("<html><center><span style=\'font-size:14px\'>" + ico + "</span><br><span style=\'font-size:10px\'>" + lbl + "</span></center></html>");
                    setFont(new Font("Segoe UI Emoji", Font.PLAIN, 13));
                    setForeground(col);
                    setBackground(Color.WHITE);
                    setPreferredSize(new Dimension(80, 56));
                    setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(col, 1, true),
                        BorderFactory.createEmptyBorder(4,8,4,8)));
                    setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                    setFocusPainted(false);
                }
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2 = (Graphics2D) g;
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    if (getModel().isRollover()) {
                        g2.setColor(new Color(col.getRed(), col.getGreen(), col.getBlue(), 22));
                        g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                    } else {
                        g2.setColor(Color.WHITE);
                        g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                    }
                    super.paintComponent(g);
                }
            };
            b.setContentAreaFilled(false);
            b.setOpaque(false);
            b.addActionListener(actions[i]);
            bar.add(b);
        }
        return bar;
    }

    private JButton iconLabelBtn(String icon, String label, Color color) {
        JButton btn = new JButton() {
            {
                setText("<html><center><span style=\'font-size:16px\'>" + icon + "</span><br><span style=\'font-size=10px\'>" + label + "</span></center></html>");
                setFont(new Font("Segoe UI Emoji", Font.PLAIN, 12));
                setForeground(color);
                setBackground(Color.WHITE);
                setPreferredSize(new Dimension(label.length() > 10 ? 140 : 90, 56));
                setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(color, 1, true),
                    BorderFactory.createEmptyBorder(5, 12, 5, 12)));
                setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                setFocusPainted(false);
            }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getModel().isRollover()) {
                    g2.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), 25));
                    g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                } else {
                    g2.setColor(Color.WHITE);
                    g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                }
                super.paintComponent(g);
            }
        };
        btn.setContentAreaFilled(false);
        btn.setOpaque(false);
        return btn;
    }

    private JTextField styledField(String hint){
        JTextField f=new JTextField();
        f.setFont(new Font("Segoe UI",Font.PLAIN,14));
        f.setPreferredSize(new Dimension(0,40));
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_CLR,1,true),
                BorderFactory.createEmptyBorder(6,12,6,12)));
        return f;
    }

    private void stylePassField(JPasswordField f){
        f.setFont(new Font("Segoe UI",Font.PLAIN,14));
        f.setPreferredSize(new Dimension(0,40));
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_CLR,1,true),
                BorderFactory.createEmptyBorder(6,12,6,12)));
    }

    private JLabel boldLabel(String text){
        JLabel l=new JLabel(text);
        l.setFont(new Font("Segoe UI",Font.BOLD,12));
        l.setForeground(TEXT_DARK);
        return l;
    }

    private JButton primaryBtn(String text,Color bg){
        JButton btn=new JButton(text){
            @Override protected void paintComponent(Graphics g){
                Graphics2D g2=(Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                Color c=getModel().isPressed()?bg.darker():getModel().isRollover()?bg.brighter():bg;
                g2.setColor(c);g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                super.paintComponent(g);
            }
        };
        btn.setFont(new Font("Segoe UI",Font.BOLD,13));
        btn.setForeground(Color.WHITE);btn.setOpaque(false);
        btn.setContentAreaFilled(false);btn.setBorderPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(btn.getPreferredSize().width+20,38));
        return btn;
    }

    private JButton outlineBtn(String text){
        JButton btn=new JButton(text);
        btn.setFont(new Font("Segoe UI",Font.PLAIN,13));
        btn.setForeground(PRIMARY);btn.setBackground(CARD_BG);
        btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(PRIMARY,1,true),
                BorderFactory.createEmptyBorder(6,14,6,14)));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private void updateStatus(String msg){
        if(statusLabel!=null)statusLabel.setText("  "+msg);
        System.out.println(msg);
    }

    public static void main(String[] args){
        SwingUtilities.invokeLater(()->{
            try{UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());}
            catch(Exception ignored){}
            new EmailClientGUI().setVisible(true);
        });
    }
}