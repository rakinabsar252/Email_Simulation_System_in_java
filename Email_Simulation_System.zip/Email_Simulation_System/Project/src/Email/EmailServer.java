package email;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

class User implements Serializable {
    private static final long serialVersionUID = 1L;
    String username;
    String password;
    List<EmailData> inbox;
    List<EmailData> outbox;

    User(String username, String password) {
        this.username = username;
        this.password = password;
        this.inbox = new ArrayList<>();
        this.outbox = new ArrayList<>();
    }
}

class EmailData implements Serializable {
    private static final long serialVersionUID = 2L;
    String from;
    String to;
    String subject;
    String body;
    String timestamp;
    String attachmentPath;
    String attachmentName;
    String status;
    String messageId;

    EmailData(String from, String to, String subject, String body,
              String attachmentPath, String attachmentName) {
        this.from = from;
        this.to = to;
        this.subject = subject;
        this.body = body;
        this.attachmentPath = attachmentPath;
        this.attachmentName = attachmentName;
        this.timestamp = new Date().toString();
        this.status = "active";
        this.messageId = UUID.randomUUID().toString();
    }
}

public class EmailServer {
    private static final int PORT = 5000;
    static Map<String, User> users = new ConcurrentHashMap<>();
    private static ExecutorService threadPool = Executors.newCachedThreadPool();
    private static ServerSocket serverSocket;

    public static void main(String[] args) {
        new File("server_attachments").mkdirs();

        // Default demo users
        users.put("alice",   new User("alice",   "alice123"));
        users.put("bob",     new User("bob",     "bob123"));
        users.put("charlie", new User("charlie", "charlie123"));

        loadData(); // overwrite defaults if saved data exists

        try {
            serverSocket = new ServerSocket(PORT);
            System.out.println("Email Server started on port " + PORT);
            System.out.println("=====================================");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("New client connected: " + clientSocket.getInetAddress());
                threadPool.execute(new ClientHandler(clientSocket));
            }
        } catch (IOException e) {
            System.err.println("Server error: " + e.getMessage());
        }
    }

    static synchronized void saveData() {
        try (ObjectOutputStream oos = new ObjectOutputStream(
                new FileOutputStream("server_data.ser"))) {
            oos.writeObject(users);
        } catch (IOException e) {
            System.err.println("Error saving data: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    static void loadData() {
        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream("server_data.ser"))) {
            Map<String, User> saved = (Map<String, User>) ois.readObject();
            // Merge: saved users override defaults
            users.putAll(saved);
            System.out.println("Data loaded. Users: " + users.keySet());
        } catch (FileNotFoundException e) {
            System.out.println("No saved data found, starting fresh.");
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading data: " + e.getMessage());
        }
    }

    // ─────────────────────────────────────────────────────────────
    static class ClientHandler implements Runnable {
        private final Socket socket;
        private ObjectOutputStream out;
        private ObjectInputStream in;
        private String currentUser;

        ClientHandler(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try {
                out = new ObjectOutputStream(socket.getOutputStream());
                out.flush();
                in  = new ObjectInputStream(socket.getInputStream());

                while (true) {
                    String command = (String) in.readObject();
                    System.out.println("CMD: " + command + " | user: " + currentUser);

                    switch (command) {
                        case "REGISTER":         handleRegister();       break;
                        case "LOGIN":            handleLogin();          break;
                        case "SEND_EMAIL":       handleSendEmail();      break;
                        case "GET_INBOX":        handleGetInbox();       break;
                        case "GET_OUTBOX":       handleGetOutbox();      break;
                        case "DELETE_EMAIL":     handleDeleteEmail();    break;
                        case "EDIT_EMAIL":       handleEditEmail();      break;
                        case "DELETE_FOR_ME":    handleDeleteForMe();    break;
                        case "UPLOAD_ATTACHMENT":   handleUploadAttachment();   break;
                        case "DOWNLOAD_ATTACHMENT": handleDownloadAttachment(); break;
                        case "LOGOUT":           handleLogout(); return;
                        default:
                            out.writeObject("ERROR");
                            out.writeObject("Unknown command: " + command);
                            out.flush();
                    }
                }
            } catch (SocketException | EOFException e) {
                System.out.println("Client disconnected: " + currentUser);
            } catch (IOException | ClassNotFoundException e) {
                System.err.println("Handler error [" + currentUser + "]: " + e.getMessage());
            } finally {
                try { socket.close(); } catch (IOException ignored) {}
            }
        }

        // ── REGISTER ──────────────────────────────────────────────
        private void handleRegister() throws IOException, ClassNotFoundException {
            String username = (String) in.readObject();
            String password = (String) in.readObject();

            if (username == null || username.trim().isEmpty()) {
                send("FAILED", "Username cannot be empty.");
                return;
            }
            if (users.containsKey(username.trim().toLowerCase())) {
                send("FAILED", "Username '" + username + "' already taken.");
                return;
            }

            String key = username.trim().toLowerCase();
            users.put(key, new User(key, password));
            saveData();
            send("SUCCESS", "Account created! You can now login as " + key);
            System.out.println("New user registered: " + key);
        }

        // ── LOGIN ─────────────────────────────────────────────────
        private void handleLogin() throws IOException, ClassNotFoundException {
            String username = ((String) in.readObject()).trim().toLowerCase();
            String password = (String) in.readObject();

            User user = users.get(username);
            if (user != null && user.password.equals(password)) {
                currentUser = username;
                send("SUCCESS", "Welcome " + username + "!");
                System.out.println(username + " logged in.");
            } else {
                send("FAILED", "Invalid username or password.");
            }
        }

        // ── SEND EMAIL ────────────────────────────────────────────
        private void handleSendEmail() throws IOException, ClassNotFoundException {
            if (currentUser == null) { send("FAILED", "Not logged in."); return; }

            String to             = ((String) in.readObject()).trim().toLowerCase();
            String subject        = (String) in.readObject();
            String body           = (String) in.readObject();
            String attachmentPath = (String) in.readObject();
            String attachmentName = (String) in.readObject();

            User sender   = users.get(currentUser);
            User receiver = users.get(to);

            if (receiver == null) {
                send("FAILED", "User '" + to + "' does not exist.");
                return;
            }

            EmailData email = new EmailData(currentUser, to, subject, body,
                                            attachmentPath, attachmentName);
            synchronized (EmailServer.class) {
                sender.outbox.add(email);
                receiver.inbox.add(email);
            }
            saveData();
            send("SUCCESS", "Email sent to " + to + "!");
            System.out.println("Mail: " + currentUser + " → " + to);
        }

        // ── GET INBOX ─────────────────────────────────────────────
        private void handleGetInbox() throws IOException {
            if (currentUser == null) { out.writeObject(new ArrayList<>()); out.flush(); return; }
            User user = users.get(currentUser);
            List<EmailData> active = new ArrayList<>();
            for (EmailData e : user.inbox) {
                if (!"deleted_by_receiver".equals(e.status)) active.add(e);
            }
            out.writeObject(active);
            out.flush();
        }

        // ── GET OUTBOX ────────────────────────────────────────────
        private void handleGetOutbox() throws IOException {
            if (currentUser == null) { out.writeObject(new ArrayList<>()); out.flush(); return; }
            User user = users.get(currentUser);
            List<EmailData> active = new ArrayList<>();
            for (EmailData e : user.outbox) {
                if (!"deleted_by_sender".equals(e.status)) active.add(e);
            }
            out.writeObject(active);
            out.flush();
        }

        // ── DELETE EMAIL ──────────────────────────────────────────
        private void handleDeleteEmail() throws IOException, ClassNotFoundException {
            String messageId = (String) in.readObject();
            String folder    = (String) in.readObject();
            User user = users.get(currentUser);
            boolean found = false;

            List<EmailData> list = "inbox".equals(folder) ? user.inbox : user.outbox;
            String newStatus     = "inbox".equals(folder) ? "deleted_by_receiver" : "deleted_by_sender";

            for (EmailData e : list) {
                if (e.messageId.equals(messageId)) {
                    e.status = newStatus; found = true; break;
                }
            }

            if (found) { saveData(); send("SUCCESS", "Email deleted."); }
            else         send("FAILED", "Email not found.");
        }

        // ── DELETE FOR ME ─────────────────────────────────────────
        private void handleDeleteForMe() throws IOException, ClassNotFoundException {
            String messageId = (String) in.readObject();
            User user = users.get(currentUser);
            boolean found = false;

            for (EmailData e : user.inbox) {
                if (e.messageId.equals(messageId)) {
                    e.status = "deleted_by_receiver"; found = true; break;
                }
            }
            if (!found) {
                for (EmailData e : user.outbox) {
                    if (e.messageId.equals(messageId)) {
                        e.status = "deleted_by_sender"; found = true; break;
                    }
                }
            }

            if (found) { saveData(); send("SUCCESS", "Deleted from your view."); }
            else         send("FAILED", "Email not found.");
        }

        // ── EDIT EMAIL ────────────────────────────────────────────
        private void handleEditEmail() throws IOException, ClassNotFoundException {
            String messageId  = (String) in.readObject();
            String newSubject = (String) in.readObject();
            String newBody    = (String) in.readObject();
            User user = users.get(currentUser);
            boolean found = false;

            for (EmailData e : user.outbox) {
                if (e.messageId.equals(messageId) && !"deleted_by_sender".equals(e.status)) {
                    e.subject   = newSubject;
                    e.body      = newBody;
                    e.timestamp = "Edited: " + new Date();
                    found = true; break;
                }
            }

            if (found) { saveData(); send("SUCCESS", "Email edited."); }
            else         send("FAILED", "Email not found or already deleted.");
        }

        // ── UPLOAD ATTACHMENT ─────────────────────────────────────
        private void handleUploadAttachment() throws IOException, ClassNotFoundException {
            String fileName = (String) in.readObject();
            long   fileSize = (Long)   in.readObject();

            String uniqueName = currentUser + "_" + System.currentTimeMillis() + "_" + fileName;
            String filePath   = "server_attachments/" + uniqueName;

            // FIX: read the raw bytes that the client wrote with out.write()
            try (FileOutputStream fos = new FileOutputStream(filePath)) {
                byte[] buffer = new byte[8192];
                long remaining = fileSize;
                InputStream rawIn = socket.getInputStream();
                // We must read from the underlying stream because the client
                // switched to raw write() after the ObjectOutputStream headers.
                // Reconstruct via ObjectInputStream's internal buffer:
                while (remaining > 0) {
                    int toRead = (int) Math.min(buffer.length, remaining);
                    int bytesRead = in.read(buffer, 0, toRead);
                    if (bytesRead == -1) break;
                    fos.write(buffer, 0, bytesRead);
                    remaining -= bytesRead;
                }
                fos.flush();
            }

            out.writeObject("SUCCESS");
            out.writeObject(filePath);
            out.writeObject(uniqueName);
            out.flush();
            System.out.println("Attachment saved: " + uniqueName);
        }

        // ── DOWNLOAD ATTACHMENT ───────────────────────────────────
        private void handleDownloadAttachment() throws IOException, ClassNotFoundException {
            String filePath = (String) in.readObject();
            File file = new File(filePath);

            if (!file.exists()) {
                send("FAILED", "Attachment not found on server.");
                return;
            }

            out.writeObject("SUCCESS");
            out.writeObject(file.length());
            out.writeObject(file.getName());
            out.flush();

            // Send raw bytes — client reads with in.read() after the object headers
            try (FileInputStream fis = new FileInputStream(file)) {
                byte[] buffer = new byte[8192];
                int bytesRead;
                while ((bytesRead = fis.read(buffer)) != -1) {
                    out.write(buffer, 0, bytesRead);
                }
                out.flush();
            }
            System.out.println("Attachment sent: " + file.getName());
        }

        // ── LOGOUT ────────────────────────────────────────────────
        private void handleLogout() throws IOException {
            send("SUCCESS", "Goodbye " + currentUser + "!");
            System.out.println(currentUser + " logged out.");
            currentUser = null;
        }

        // ── helper ────────────────────────────────────────────────
        private void send(String status, String message) throws IOException {
            out.writeObject(status);
            out.writeObject(message);
            out.flush();
        }
    }
}
